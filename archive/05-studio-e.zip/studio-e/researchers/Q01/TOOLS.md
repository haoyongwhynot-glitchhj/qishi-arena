# Q01 工具

- 行情：Finnhub Current Price（盘中）、yfinance日线（盘后复核，双源收敛差值≤0.01才采纳）
- 计算：起爆评分 = 当日涨幅 + 5日涨幅×0.5 + (量比-1)×5（量比=当日量/前5日均量）
- 台账：studio-e/positions.md、studio-e/submissions.md；看板候选池
- 规则：studio-e/CHARTER.md（E-v1.0）
