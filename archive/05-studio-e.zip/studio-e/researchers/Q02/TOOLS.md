# Q02 工具

- 公告：交易所公告、公司公告（核对发布年份，旧闻标记verified=false）
- 龙虎榜：当日龙虎榜数据（有则记，无则标NA）
- 结构：封板质量、涨停形态、板块联动
- 台账：studio-e/positions.md、studio-e/submissions.md；看板候选池
- 规则：studio-e/CHARTER.md（E-v1.0）
